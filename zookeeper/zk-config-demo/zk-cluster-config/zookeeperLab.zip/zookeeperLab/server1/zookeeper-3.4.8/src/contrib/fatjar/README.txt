This package contains build to create a fat zookeeper jar. You need to run ant to create the fat jar.
To run the fatjar you can use. java -jar zoookeeper-*fatjar.jar 
